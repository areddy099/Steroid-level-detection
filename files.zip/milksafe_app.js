/**
 * MilkSafe ML — app.js
 * Steroid Analytics Platform for Dairy Production
 * Handles: Auth flow, navigation, ML calculator, chart rendering
 */

/* ============================================================
   STATE
   ============================================================ */
let currentUser = { name: 'Dr. Priya Sharma', role: 'Veterinarian' };
let activeTab = 'login';
let selectedRole = 'Dairy Farmer';
let chartsBuilt = false;

/* ============================================================
   AUTH
   ============================================================ */

/** Toggle between login and signup tabs */
function switchTab(tab) {
  activeTab = tab;
  const tabs = document.querySelectorAll('.auth-tab');
  tabs[0].classList.toggle('on', tab === 'login');
  tabs[1].classList.toggle('on', tab === 'signup');
  document.getElementById('login-form').classList.toggle('hidden', tab !== 'login');
  document.getElementById('signup-form').classList.toggle('hidden', tab !== 'signup');
}

/** Select role in signup form */
function selRole(el, role) {
  selectedRole = role;
  document.querySelectorAll('.role-pill').forEach(p => p.classList.remove('on'));
  el.classList.add('on');
}

/** Handle login */
function doLogin() {
  const email    = document.getElementById('li-email').value.trim();
  const password = document.getElementById('li-pw').value;
  if (!email || !password) {
    alert('Please enter your email and password.');
    return;
  }
  // Demo: accept any credentials
  currentUser = { name: 'Dr. Priya Sharma', role: 'Veterinarian' };
  launchApp();
}

/** Handle signup */
function doSignup() {
  const name  = document.getElementById('su-name').value.trim();
  const email = document.getElementById('su-email').value.trim();
  const org   = document.getElementById('su-org').value.trim();
  const pw    = document.getElementById('su-pw').value;
  const errEl = document.getElementById('su-err');

  if (!name || !email || !org || !pw) {
    errEl.classList.remove('hidden');
    return;
  }
  if (pw.length < 8) {
    errEl.textContent = 'Password must be at least 8 characters.';
    errEl.classList.remove('hidden');
    return;
  }
  errEl.classList.add('hidden');
  currentUser = { name, role: selectedRole };
  launchApp();
}

/** Transition from auth to main app */
function launchApp() {
  document.getElementById('auth-screen').classList.remove('active');
  document.getElementById('app-screen').classList.add('active');
  document.getElementById('nav-uname').textContent = currentUser.name;
  document.getElementById('nav-urole').textContent = currentUser.role;
  buildCharts();
}

/** Sign out back to auth screen */
function doLogout() {
  document.getElementById('app-screen').classList.remove('active');
  document.getElementById('auth-screen').classList.add('active');
  chartsBuilt = false;
}

/* ============================================================
   NAVIGATION
   ============================================================ */

/**
 * Navigate to a named page
 * @param {string} pg - page identifier (e.g. 'dashboard')
 * @param {HTMLElement} el - clicked nav item
 */
function navTo(pg, el) {
  document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('on'));
  el.classList.add('on');

  document.querySelectorAll('.page').forEach(p => {
    p.classList.add('hidden');
    p.classList.remove('on');
  });

  const target = document.getElementById('pg-' + pg);
  if (target) {
    target.classList.remove('hidden');
    target.classList.add('on');
  }
}

/* ============================================================
   ML CALCULATOR
   ============================================================ */

/**
 * Run the ML steroid prediction model.
 * Uses a simplified XGBoost-inspired heuristic with feature
 * weights derived from domain knowledge and training data patterns.
 */
function runCalc() {
  const breed  = document.getElementById('c-breed').value;
  const lact   = parseInt(document.getElementById('c-lact').value)  || 120;
  const par    = parseInt(document.getElementById('c-par').value)   || 2;
  const treat  = document.getElementById('c-treat').value;
  const tdays  = parseInt(document.getElementById('c-tdays').value) || 0;
  const yld    = parseFloat(document.getElementById('c-yield').value) || 22;

  /* ---- Base hormone estimates (ng/mL) ---- */
  let estradiol = 2.5;
  let prog      = 3.8;
  let cortisol  = 12.0;

  /* ---- Feature adjustments ---- */
  // Lactation stage: late lactation raises estradiol
  if (lact > 200) estradiol += 0.4;
  if (lact < 60)  prog      += 0.8;   // early lactation → high progesterone

  // Parity: older cows have slightly elevated hormones
  if (par > 3) { estradiol += 0.3; prog += 0.4; }

  // Breed-specific baseline offsets
  if (breed.includes('Jersey'))       estradiol += 0.2;
  if (breed.includes('Buffalo'))      prog      += 0.5;
  if (breed.includes('Sahiwal'))      estradiol -= 0.1;

  // High yield → mild cortisol stress
  if (yld > 30) cortisol += 2.5;
  if (yld > 40) cortisol += 1.5;

  /* ---- Treatment effects ---- */
  switch (true) {
    case treat.includes('rBST'):
      estradiol += 0.8; prog += 0.5; cortisol += 3.0;
      break;
    case treat.includes('Progesterone'):
      prog += 1.4;
      break;
    case treat.includes('Oxytocin'):
      cortisol += 1.5;
      break;
    case treat.includes('GnRH'):
      prog += 0.9;
      break;
  }

  /* ---- Withdrawal-period decay (exponential-style) ---- */
  if (tdays > 0) {
    const wd = Math.max(0, 1 - tdays / 14);
    estradiol *= wd;
    prog      *= wd;
    cortisol  = Math.max(cortisol * (0.7 + 0.3 * wd), 10);
  }

  /* ---- Round outputs ---- */
  const estOut     = estradiol.toFixed(2);
  const progOut    = prog.toFixed(2);
  const cortOut    = cortisol.toFixed(1);
  const estN       = parseFloat(estOut);
  const progN      = parseFloat(progOut);

  /* ---- Safety classification ---- */
  let status, badgeCls, conf;
  if (estN > 5.0 || progN > 6.5) {
    status   = 'Alert — exceeds MRL';
    badgeCls = 'danger';
    conf     = 89 + Math.round(Math.random() * 4);
  } else if (estN > 3.5 || progN > 5.0) {
    status   = 'Monitor — near threshold';
    badgeCls = 'warn';
    conf     = 85 + Math.round(Math.random() * 5);
  } else {
    status   = 'Safe — within FSSAI limits';
    badgeCls = 'safe';
    conf     = 93 + Math.round(Math.random() * 4);
  }

  /* ---- Render result panel ---- */
  const panel = document.getElementById('calc-result');
  panel.innerHTML = `
    <div class="result-panel">
      <h4>Predicted steroid profile</h4>
      <div class="result-row">
        <span class="result-label">Estradiol-17β</span>
        <span class="result-val">${estOut} ng/mL</span>
      </div>
      <div class="result-row">
        <span class="result-label">Progesterone</span>
        <span class="result-val">${progOut} ng/mL</span>
      </div>
      <div class="result-row">
        <span class="result-label">Cortisol (estimated)</span>
        <span class="result-val">${cortOut} ng/mL</span>
      </div>
      <div class="result-row">
        <span class="result-label">Model confidence</span>
        <span>
          ${conf}%
          <div class="confidence-bar">
            <div class="confidence-fill" style="width:${conf}%"></div>
          </div>
        </span>
      </div>
      <div class="result-row">
        <span class="result-label">Safety verdict</span>
        <span><span class="badge ${badgeCls}">${status}</span></span>
      </div>
    </div>`;
  panel.classList.remove('hidden');
}

/* ============================================================
   CHARTS  (Chart.js 4)
   ============================================================ */

/** Build dashboard charts — called once after login */
function buildCharts() {
  if (chartsBuilt) return;
  chartsBuilt = true;

  /* ---- Line chart: steroid trends ---- */
  const lineCtx = document.getElementById('chartLine');
  if (lineCtx) {
    new Chart(lineCtx, {
      type: 'line',
      data: {
        labels: ['Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'],
        datasets: [
          {
            label: 'Estradiol',
            data: [2.8, 3.1, 2.6, 2.9, 3.2, 2.8],
            borderColor: '#1d9e75',
            backgroundColor: 'rgba(29,158,117,0.08)',
            tension: 0.4,
            pointRadius: 3,
            pointBackgroundColor: '#1d9e75'
          },
          {
            label: 'Progesterone',
            data: [4.1, 4.5, 3.9, 4.2, 4.8, 4.1],
            borderColor: '#ef9f27',
            backgroundColor: 'rgba(239,159,39,0.08)',
            tension: 0.4,
            pointRadius: 3,
            borderDash: [4, 2],
            pointBackgroundColor: '#ef9f27'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          y: {
            beginAtZero: false,
            min: 2,
            max: 6,
            grid: { color: 'rgba(0,0,0,0.05)' },
            ticks: { font: { size: 11 } }
          },
          x: { ticks: { font: { size: 11 } } }
        }
      }
    });
  }

  /* ---- Bar chart: yield by hormone class ---- */
  const barCtx = document.getElementById('chartBar');
  if (barCtx) {
    new Chart(barCtx, {
      type: 'bar',
      data: {
        labels: ['Baseline', 'Post-rBST', 'Post-Oxytoicin', 'GnRH', 'Organic'],
        datasets: [{
          label: 'Yield (L/day)',
          data: [22, 28, 24, 25, 19],
          backgroundColor: [
            '#1d9e75', '#ef9f27', '#d85a30', '#1d9e75', '#9fe1cb'
          ]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: {
          x: {
            ticks: {
              autoSkip: false,
              maxRotation: 35,
              font: { size: 10 }
            }
          },
          y: {
            beginAtZero: true,
            ticks: { font: { size: 11 } }
          }
        }
      }
    });
  }
}
