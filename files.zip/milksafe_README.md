# MilkSafe ML — Steroid Analytics Platform

A production-ready, single-page web application for monitoring and predicting steroid hormone levels in dairy milk production using machine learning.

---

## Files

| File        | Description                                      |
|-------------|--------------------------------------------------|
| `index.html`| Main HTML — all screens, pages, and SVG diagrams |
| `style.css` | Full stylesheet with responsive design            |
| `app.js`    | Auth logic, navigation, ML calculator, charts     |

---

## Features

### Authentication
- **Sign in / Sign up** with tab-based interface
- Role selection: Dairy Farmer, Lab Analyst, Veterinarian, Regulator
- License/registration number field
- Password validation (minimum 8 characters)

### Dashboard
- 4 live stat cards: Avg Estradiol, Progesterone, Cortisol spikes, Alerts
- **Line chart**: Steroid trends over 6 months (Chart.js)
- **Bar chart**: Milk yield by hormone treatment class
- Batch alert table with Safe / Monitor / Alert badges

### ML Steroid Calculator
Input parameters:
- Breed (Holstein, Jersey, Sahiwal, Gir, Murrah Buffalo)
- Lactation stage (days), Parity, Body Condition Score
- Hormonal treatment (rBST, Oxytocin, Progesterone, GnRH, None)
- Days since last treatment, Daily milk yield, Collection temperature

Outputs:
- **Estradiol-17β** (ng/mL)
- **Progesterone** (ng/mL)
- **Cortisol** (ng/mL)
- Model confidence score with visual bar
- FSSAI safety verdict (Safe / Monitor / Alert)

Model: XGBoost v2 | R² = 0.94 | Training set: 48,320 samples

### Flow Charts (SVG)
1. **Steroid biosynthesis pathway** — Cholesterol → Pregnenolone → Progesterone → Androstenedione → Estradiol → Secreted into milk
2. **Milk safety testing workflow** — Sample collection → ELISA/LC-MS → ML model → Pass/Flag → Approve/Quarantine → Regulatory report

### Sample Records
Full historical table with: Sample ID, Animal ID, Date, Estradiol, Progesterone, Cortisol, Confidence, Status

### Profile & Credentials
- Editable personal info (name, email, phone, organisation, role, license)
- Certifications with active/expired status:
  - BVSc & AH degree
  - FSSAI Food Safety Certification
  - Codex Alimentarius Dairy Standards
  - ML in Veterinary Diagnostics — NDRI

---

## How to Run

1. Download all three files into the same folder
2. Open `index.html` in any modern browser
3. Use the demo credentials (pre-filled) or create a new account

No server or npm install required — runs entirely in the browser.

---

## Regulatory Standards Referenced
- **FSSAI** (Food Safety and Standards Authority of India) — MRL thresholds
- **Codex Alimentarius** — International dairy hormone guidelines
- **Estradiol-17β MRL**: ~5.0 ng/mL (alert threshold)
- **Progesterone MRL**: ~6.5 ng/mL (alert threshold)

---

## Tech Stack
- Vanilla HTML5, CSS3, JavaScript (ES6+)
- [Chart.js 4.4.1](https://www.chartjs.org/) — dashboard charts
- [DM Serif Display + DM Sans](https://fonts.google.com/) — typography (Google Fonts)
- Inline SVG — flow diagrams
- Zero dependencies / no build step

---

## Customisation Tips

**Add more breeds**: Edit the `<select id="c-breed">` in `index.html` and add offset values in `runCalc()` in `app.js`.

**Change MRL thresholds**: Edit the safety classification block in `runCalc()`:
```js
if (estN > 5.0 || progN > 6.5) { ... }   // Alert
if (estN > 3.5 || progN > 5.0) { ... }   // Monitor
```

**Connect a real backend**: Replace `doLogin()` and `doSignup()` in `app.js` with `fetch()` calls to your API.

**Add more charts**: Use `new Chart(canvas, config)` and place a `<canvas>` element in any page in `index.html`.
